package com.example.proyectodw.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Nave{
    @Id
    @GeneratedValue
    int ID;
    String nombre;
    int carga;
    int velocidad;
    @ManyToOne
    Estrella estrella;
    @OneToMany(mappedBy="nave")
    List<Usuario> usuarios = new ArrayList<>();

    public Nave() {
    }

    public Nave(String nombre, int carga, int velocidad, Estrella estrella) {
        this.nombre = nombre;
        this.carga = carga;
        this.velocidad = velocidad;
        this.estrella = estrella;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        this.carga = carga;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public Estrella getEstrella() {
        return estrella;
    }

    public void setEstrella(Estrella estrella) {
        this.estrella = estrella;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    

}
