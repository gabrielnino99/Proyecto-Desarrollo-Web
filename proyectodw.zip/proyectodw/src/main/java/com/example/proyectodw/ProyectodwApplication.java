package com.example.proyectodw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectodwApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectodwApplication.class, args);
	}

}
